How to Apply the Built-In Custom Styles?


STEP 1 - Go to your site > Theme > Edit HTML > And find the "Customize Options" code.


Example:

/*-- Customize Options (Start) --
..........
..........
..........
-- Customize Options (End) --*/


STEP 2 - Replace the "Customize Options" code with the desired option "Magspot-Style" or "Starter-Style".


IMPORTANT: After replacing the customization code and save, All changes made previously will be lost.


DONE: After closing the Blogger HTML Editor, you can navigate to the customize page to make necessary adjustments.


Regards,
Pro Blogger Templates (Team)